#include <iostream>
#include "Menu.h"

using namespace std;

int main()
{
	Menu menu;
	menu.manager();

	system("pause");
	return 0;
}